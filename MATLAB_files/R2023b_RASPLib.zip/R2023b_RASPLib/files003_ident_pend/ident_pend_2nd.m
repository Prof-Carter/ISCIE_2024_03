clear
format compact
close all

myred   = [232   71   70]/255;
myblue	= [  0  112  192]/255;
mygreen	= [ 12  162  116]/255;
mypink	= [255  102  153]/255;
myskyblue    = [  0  176  240]/255;
mydarkpink   = [227   45  145]/255;
mydarkyellow = [228  131   18]/255;

% -----------------------
g = 9.81e+00;
% -----------------------
load ident_pend_data

tmin = 5;
tmax = 30;

% -----------------------
figure(1)
set(gcf,'Position',[80 80 800 300]) % [x0 y0 width height]
subplot('Position',[0.11 0.2 0.85 0.75])

area([0 tmin], 110*[1 1],'FaceColor',mydarkyellow,'FaceAlpha',0.1,'EdgeAlpha',0)
hold on
area([0 tmin],-110*[1 1],'FaceColor',mydarkyellow,'FaceAlpha',0.1,'EdgeAlpha',0)
plot([tmin tmin],[-110 110],'Color',mydarkyellow)

q1 = stairs(t,phi2*180/pi,'Color',myred,'LineWidth',1.5);
hold off

xlim([0 15])
ylim([-110 110])

set(gca,'XTick',0:1:15)
set(gca,'YTick',-90:30:90)

set(gca,'FontName','arial','FontSize',16)
xlabel('$$t$$ [s]', 'interpreter', 'latex','FontSize',18)
ylabel('$${\phi}_{2}(t)$$ [deg]', 'interpreter', 'latex','FontSize',18)

grid on

% -----
figure(2)
set(gcf,'Position',[120 120 800 300]) % [x0 y0 width height]
subplot('Position',[0.11 0.2 0.85 0.75])

area([tmax t(end)], 110*[1 1],'FaceColor',mydarkyellow,'FaceAlpha',0.1,'EdgeAlpha',0.1)
hold on
area([tmax t(end)],-110*[1 1],'FaceColor',mydarkyellow,'FaceAlpha',0.1,'EdgeAlpha',0.1)
plot([tmax tmax],[-110 110],'Color',mydarkyellow)

r1 = stairs(t,phi2*180/pi,'Color',myred,'LineWidth',1.5);

xlim([15 30])
ylim([-110 110])

set(gca,'XTick',15:1:30)
set(gca,'YTick',-90:30:90)

set(gca,'FontName','arial','FontSize',16)
xlabel('$$t$$ [s]', 'interpreter', 'latex','FontSize',18)
ylabel('$${\phi}_{2}(t)$$ [deg]', 'interpreter', 'latex','FontSize',18)

grid on

% -----------------------
t_data = t;
phi2_data = phi2;

clear t phi2
% -----------------------
k = 0;
for i = 1:length(t_data)
    if t_data(i) >= tmin & t_data(i) <= tmax
        k = k + 1;
        t(k)    = t_data(i) - tmin;
        phi2(k) = phi2_data(i);
    end
end

% ++++++++++ Step 1 ++++++++++
k = 0;
flag = 0;

for i = 1:length(t)-1
    if phi2(i) > 0 
        flag = 1;
    end
    if flag == 1 & phi2(i) < 0
        k = k + 1;
        num(k) = i;
        t0(k)  = t(i);
        A0(k)  = phi2(i);
        flag   = 0;
    end
end
% -----------------------
if phi2(1) < 0
    num = [1 num];
end
% -----------------------
for j = 1:length(num)-1   
    [A(j) imax(j)] = max(phi2(num(j):num(j+1)));
    imax(j) = imax(j) + num(j);

    imax_last(j) = imax(j);
    for i = imax(j):num(j+1)
        if phi2(i) == A(j)
            imax_last(j) = i;
        end
        if phi2(i) < A(j)
            break
        end
    end

    tb(j) = (t(imax(j)) + t(imax_last(j)))/2;
end

% ++++++++++ Step 2 ++++++++++
for i = 1:length(tb)-1
    T(i)      = tb(i+1) - tb(i);
    lambda(i) = A(i+1)/A(i);
end

T_ave      = mean(T);
lambda_ave = mean(lambda);

fprintf('T      = %3.2e\n',T_ave)
fprintf('lambda = %3.2e\n',lambda_ave)

% ++++++++++ Step 3 ++++++++++
xi2   = (1/T_ave)*log(1/lambda_ave);
wn2   = sqrt((2*pi/T_ave)^2 + xi2^2);
zeta2 = xi2/wn2;

fprintf('wn2   = %3.2e\n',wn2)
fprintf('zeta2 = %3.2e\n',zeta2)

a2 = g/wn2^2;
b2 = 2*zeta2*wn2*a2;

fprintf('a2 = %3.2e\n',a2)
fprintf('b2 = %3.2e\n',b2)

% -----------------------
figure(3)
set(gcf,'Position',[80 80 800 300]) % [x0 y0 width height]
subplot('Position',[0.11 0.2 0.85 0.75])

plot(1:length(T),T,'o','Color',mydarkyellow,'LineWidth',1.5,'MarkerSize',8)
hold on
plot([1 length(T)],T_ave*[1 1],'Color',[  0 112 192]/255)
hold off
xlim([1 length(lambda)]);
ylim([0.7 1])
set(gca,'FontName','arial','FontSize',16)
xlabel('$$i$$', 'interpreter', 'latex','FontSize',18)
ylabel('$${T}_{i}$$ and $$T$$ [s]', 'interpreter', 'latex','FontSize',18)

xtickangle(0)
set(gca,'XTick',1:1:length(lambda))
set(gca,'YTick',0.7:0.05:1)

grid on

% -----------------------
figure(4)
set(gcf,'Position',[80 80 800 300]) % [x0 y0 width height]
subplot('Position',[0.11 0.2 0.85 0.75])

plot(1:length(lambda),lambda,'o','Color',mydarkyellow,'LineWidth',1.5,'MarkerSize',8)
hold on
plot([1 length(lambda)],lambda_ave*[1 1],'Color',[  0 112 192]/255)
hold off
xlim([1 length(lambda)]);
ylim([0.8 1])
set(gca,'FontName','arial','FontSize',16)
xlabel('$$i$$', 'interpreter', 'latex','FontSize',18)
ylabel('$${\lambda}_{i}$$ and $$\lambda$$', 'interpreter', 'latex','FontSize',18)

xtickangle(0)
set(gca,'XTick',1:1:length(lambda))
set(gca,'YTick',0.8:0.05:1)

grid on

% -----------------------
wd2 = wn2*sqrt(1 - zeta2^2);
phi20 = A(1);

tsim = 0:0.001:(tmax-tmin)-tb(1);
phi2sim = exp(-zeta2*wn2*tsim).*(cos(wd2*tsim) + zeta2/sqrt(1 - zeta2^2)*sin(wd2*tsim))*phi20;

figure(5)
set(gcf,'Position',[80 80 800 300]) % [x0 y0 width height]
subplot('Position',[0.11 0.2 0.85 0.75])

p1 = plot(tsim+tb(1),phi2sim*180/pi,'Color',mygreen,'LineWidth',1.5);
hold on
plot(tb,A*180/pi,'o','Color',mydarkyellow,'LineWidth',1.5,'MarkerSize',8);
p2 = stairs(t,phi2*180/pi,'Color',myred,'LineWidth',1.5);

hold off

xlim([0 tmax-tmin])
ylim([-90 90])

set(gca,'FontName','arial','FontSize',16)
xlabel('$$t$$ [s]', 'interpreter', 'latex','FontSize',18)
ylabel('$${\phi}_{2}(t)$$ [deg]', 'interpreter', 'latex','FontSize',18)

legend([p2 p1],{'Experiment','Linear Simulation'},'Location','southeast')

xtickangle(0)
set(gca,'XTick',0:1:tmax-tmin)
set(gca,'YTick',-90:30:90)

grid on

% ----------------------- ����`�V�~�����[�V����
[phi20 i] = max(phi2);
t0 = t(i);

sim('sim_nonlinear_pend')

figure(6)
set(gcf,'Position',[80 80 800 300]) % [x0 y0 width height]
subplot('Position',[0.11 0.2 0.85 0.75])

p1 = plot(tsim,phi2sim*180/pi,'Color',mygreen,'LineWidth',1.5);
hold on
plot(tb(1),phi20*180/pi,'o','Color',mydarkyellow,'LineWidth',1.5,'MarkerSize',8);
p2 = stairs(t,phi2*180/pi,'Color',myred,'LineWidth',1.5);
hold off

xlim([0 tmax-tmin])
ylim([-90 90])

set(gca,'FontName','arial','FontSize',14)
xlabel('$$t$$ [s]', 'interpreter', 'latex','FontSize',16)
ylabel('$${\phi}_{2}(t)$$ [deg]', 'interpreter', 'latex','FontSize',16)

legend([p2 p1],{'Experiment','Nonlinear Simulation'},'Location','southeast')

xtickangle(0)
set(gca,'XTick',0:1:tmax-tmin)
set(gca,'YTick',-90:30:90)

grid on

% ================================
figure(1); movegui('northwest')
figure(2); movegui('northeast')
figure(3); movegui('west')
figure(4); movegui('east')
figure(5); movegui('southwest')
figure(6); movegui('southeast')

