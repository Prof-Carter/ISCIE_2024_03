open_system('ex_p_cont.slx');
Simulink.exportToVersion('ex_p_cont','R2021b/ex_p_cont','R2021b')
Simulink.exportToVersion('ex_p_cont','R2022a/ex_p_cont','R2022a')
Simulink.exportToVersion('ex_p_cont','R2022b/ex_p_cont','R2022b')
close_system('ex_p_cont.slx');

open_system('sim_p_cont.slx');
Simulink.exportToVersion('sim_p_cont','R2021b/sim_p_cont','R2021b')
Simulink.exportToVersion('sim_p_cont','R2022a/sim_p_cont','R2022a')
Simulink.exportToVersion('sim_p_cont','R2022b/sim_p_cont','R2022b')
close_system('sim_p_cont.slx');
